/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gmexp
 */
import java.util.Scanner;
public class ProgrammingExcercise5 
{

    var myArray1 = new Array(3);
    
    public static void main(String[] args) 
    {
       for(i = 0; i < 3; i++)
        myArray1[i] = new Array(3);
       
       
       myArray1[0][20] = "Test";
       
       for(var i = 0; i < 3; i++)
       {
           for(var j = 0; j < 3; j++)
           {
            document.write(myArray1[i][j] + "test");   
           }
           document.write("<br/>");
       }
           
           
    }
    
}
